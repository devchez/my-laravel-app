<h1 style="color: blue"> Welcome <h1>
<p>This is a blog section</p>
<a href="{{ route('index') }}">Go Back to index</a>