<!-- Footer -->
  <footer class="bg-dark text-white text-center py-3">
    <div class="container">
      <p class="mb-1">&copy; 2025 YourBrand. All rights reserved.</p>
      <small>Follow us:
        <a href="#" class="text-white ms-2">Facebook</a> |
        <a href="#" class="text-white ms-2">Twitter</a> |
        <a href="#" class="text-white ms-2">Instagram</a>
      </small>
    </div>
  </footer>