<div class="card">
    <div class="card-header">
        {{ $header }}
    </div>
    <div class="card-body">
        <h1>{{ $name }}</h1>
        <h2>{{ $text }}</h2>
        <p>{{ $slot }}</p>
    </div>
</div>