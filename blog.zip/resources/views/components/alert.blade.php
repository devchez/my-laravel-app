<div class="alert alert-{{$type }}">
  <strong>{{ $slot}}</strong>
</div>